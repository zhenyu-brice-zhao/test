package com.example.todolist_1

import android.content.Intent
import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.preference.PreferenceManager

class MainActivity : AppCompatActivity() {
    var sp : SharedPreferences? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        val btnOk = findViewById<Button>(R.id.btn_ok)
        val etPseudo = findViewById<EditText>(R.id.et_name)
        var editor:SharedPreferences.Editor? = null
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        sp = getPreferences(MODE_PRIVATE)


    }

    override fun onStart() {


        super.onStart()
        val btnOk = findViewById<Button>(R.id.btn_ok)
        val etPseudo = findViewById<EditText>(R.id.et_name)
        val DefaultName = ""
        val SharePseudo: String? = sp?.getString("pseudo",DefaultName)
        etPseudo.setText(SharePseudo)

        btnOk.setOnClickListener{

            //preference
            val pseudo = etPseudo!!.text.toString()
            if(pseudo==""){
                Toast.makeText(this@MainActivity, "Input your name", Toast.LENGTH_LONG).show()
            }
            else{
                with (sp?.edit()) {
                    this?.putString("pseudo", pseudo.toString())
                    this?.apply()
                }
                //change to the second activity
                val iChoixListA:Intent = Intent(this, ChoixListActivity::class.java)
                startActivity(iChoixListA)
            }


        }
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.menu, menu)
        return true
    }
    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        val id = item.itemId

        when(id) {
            R.id.menu_setting -> {
                val intent = Intent(this, SettingActivity::class.java)
                startActivity(intent)
            }
        }
        return super.onOptionsItemSelected(item)
    }

}